/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/04 18:14:58 by gcherqui          #+#    #+#             */
/*   Updated: 2022/08/04 23:46:44 by gcherqui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int	signe;
	int	i;
	int	result;

	signe = 0;
	i = 0;
	while (i < length - 1)
	{
		result = f(tab[i], tab[i + 1]);
		if (!signe)
			signe = result;
		if (signe != 0)
		{
			if (signe < 0 && result > 0)
				return (0);
			if (signe > 0 && result < 0)
				return (0);
		}
		i++;
	}
	return (1);
}
