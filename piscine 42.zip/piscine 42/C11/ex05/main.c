/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/04 18:16:09 by gcherqui          #+#    #+#             */
/*   Updated: 2022/08/04 18:16:16 by gcherqui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putnbr(int nb);
int		ft_atoi(char *str);

int	verif2(char sign, int nbr2)
{
	if (nbr2 == 0)
	{
		if (sign == '/')
		{
			write(1, "Stop : division by zero\n", 24);
			return (0);
		}
		else if (sign == '%')
		{
			write(1, "Stop : modulo by zero\n", 22);
			return (0);
		}
	}
	return (1);
}

int	do_op(char *nbr1, char sign, char *nbr2)
{
	int	nbr11;
	int	nbr22;
	int	result;

	result = 0;
	nbr11 = ft_atoi(nbr1);
	nbr22 = ft_atoi(nbr2);
	if (!(verif2(sign, nbr22)))
		return (3);
	if (sign == '+')
		result = nbr11 + nbr22;
	else if (sign == '-')
		result = nbr11 - nbr22;
	else if (sign == '*')
		result = nbr11 * nbr22;
	else if (sign == '/')
		result = nbr11 / nbr22;
	else if (sign == '%')
		result = nbr11 % nbr22;
	return (result);
}

int	main(int ac, char **av)
{
	int	a;

	if (ac == 4)
	{
		a = do_op(av[1], av[2][0], av[3]);
		if (!(a == 3))
		{
			ft_putnbr(a);
			write(1, "\n", 1);
		}
	}
}
