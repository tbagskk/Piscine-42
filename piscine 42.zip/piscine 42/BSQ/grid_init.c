/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   grid_init.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/01 23:28:25 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/03 16:13:30 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "bsq.h"

int	init_params(t_grid_info *grid_info, int FILE_READ)
{
	char	*params;
	char	buff[1];
	int		r;

	params = malloc(sizeof(char *));
	if (!params)
		return (0);
	r = 0;
	while (read(FILE_READ, buff, sizeof(buff)))
	{
		if (*buff == '\n')
			break ;
		else
			params[r++] = *buff;
	}
	(*grid_info).height = ft_atoi(params, r - 3);
	(*grid_info).width = ft_atoi(params, r - 3);
	(*grid_info).empty_char = params[r - 3];
	(*grid_info).obstacle_char = params[r - 2];
	(*grid_info).fill_char = params[r - 1];
	free(params);
	return (1);
}

int	line_length(char *buffer)
{
	int	length;

	length = 0;
	while (*buffer && *buffer == '\n')
		buffer++;
	while (buffer[length] && buffer[length] != '\n' && buffer[length] != EOF)
		length++;
	return (length);
}

int	verif_params(t_grid_info grid_info)
{
	if (!grid_info.empty_char
		|| !grid_info.fill_char || !grid_info.obstacle_char)
		return (0);
	if ((grid_info.empty_char == grid_info.fill_char
			|| grid_info.empty_char == grid_info.obstacle_char
			|| grid_info.fill_char == grid_info.obstacle_char))
		return (0);
	return (1);
}

int	verif_char(t_grid_info grid_info, char c)
{
	return (!(c != grid_info.empty_char
			&& c != grid_info.fill_char
			&& c != grid_info.obstacle_char));
}

int	verif_grid(t_grid_info grid_info)
{
	int	i;
	int	j;

	if (!grid_info.height || !grid_info.width)
		return (0);
	if (!verif_params(grid_info))
		return (0);
	i = 0;
	while (i < grid_info.height)
	{
		j = 0;
		while (grid_info.grid[i][j] && grid_info.grid[i][j] != '\n')
		{
			if (!verif_char(grid_info, grid_info.grid[i][j]))
				return (0);
			j++;
		}
		if (j != grid_info.width)
			return (0);
		i++;
	}
	return (1);
}
