/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_grid_init.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/01 23:26:14 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/03 16:08:32 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "bsq.h"

void	fill_file_grid(t_grid_info grid_info, char *buffer)
{
	int	i;
	int	j;
	int	r;

	i = 0;
	r = 0;
	while (i < grid_info.height)
	{
		grid_info.grid[i] = malloc((grid_info.width + 1) * sizeof(char));
		if (!grid_info.grid[i])
			return ;
		j = 0;
		while (buffer[r])
		{
			if ((buffer[r] == '\n' || buffer[r] == EOF) && r++)
			{
				grid_info.grid[i][j] = 0;
				break ;
			}
			else
				grid_info.grid[i][j++] = buffer[r++];
		}
		i++;
	}
	grid_info.grid[i - 1][j] = 0;
}

int	ft_strlen(char *buff)
{
	int	i;

	i = 0;
	while (buff[i])
		i++;
	return (i);
}

void	empty(char *buff)
{
	while (*buff)
		*buff++ = 0;
}

t_grid_info	file_grid(char *file, char *buff)
{
	t_grid_info	grid_info;
	int			filed;
	int			r;

	grid_info.grid = NULL;
	grid_info.height = 0;
	filed = open(file, O_RDONLY);
	if (filed == -1)
		return (grid_info);
	if (!init_params(&grid_info, filed))
		return (grid_info);
	grid_info.grid = malloc(grid_info.height * sizeof(char *));
	if (!grid_info.grid)
		return (grid_info);
	empty(buff);
	r = read(filed, buff, BUFFER_SIZE);
	close(filed);
	grid_info.width = line_length(buff);
	if (!r)
		return (grid_info);
	fill_file_grid(grid_info, buff);
	return (grid_info);
}
