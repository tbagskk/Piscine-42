/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   unleaks.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/03 16:14:42 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/03 16:20:02 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "bsq.h"

int	max(int a, int b, int c)
{
	int	min;

	min = 0;
	if (a > b)
		min = b;
	else
		min = a;
	if (min > c)
		min = c;
	return (min + 1);
}

t_grid_solution	generate_solution(t_grid_info grid_info)
{
	t_grid_solution	grid_solution;
	int				i;
	int				j;

	grid_solution.grid = malloc(grid_info.height * sizeof(int *));
	i = -1;
	while (++i < grid_info.height)
	{
		j = -1;
		grid_solution.grid[i] = malloc(grid_info.width * sizeof(int));
		while (++j < grid_info.width)
		{
			if (grid_info.grid[i][j] == grid_info.obstacle_char)
				grid_solution.grid[i][j] = 0;
			else if (i == 0 || j == 0)
				grid_solution.grid[i][j] = 1;
			else
			{
				grid_solution.grid[i][j] = max(grid_solution.grid[i - 1][j - 1],
						grid_solution.grid[i - 1][j],
						grid_solution.grid[i][j - 1]);
			}
		}
	}
	return (grid_solution);
}

void	solve_grid(t_grid_info grid_info)
{
	t_grid_solution	grid_solution;
	t_point			biggest;
	int				i;
	int				j;

	grid_solution = generate_solution(grid_info);
	i = 0;
	biggest.value = 0;
	while (i < grid_info.height)
	{
		j = -1;
		while (++j < grid_info.width)
		{
			if (grid_solution.grid[i][j] > biggest.value)
			{
				biggest.value = grid_solution.grid[i][j];
				biggest.x = j;
				biggest.y = i;
			}
		}
		free(grid_solution.grid[i]);
		i++;
	}
	free(grid_solution.grid);
	print_solve(grid_info, biggest);
}
