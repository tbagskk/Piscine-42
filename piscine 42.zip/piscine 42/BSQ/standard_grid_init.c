/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   standard_grid_init.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/01 23:29:03 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/01 23:42:16 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "bsq.h"

void	fill_grid(t_grid_info *grid_info, int i, int j)
{
	char	buff[1];

	i = 0;
	while (i < (*grid_info).height)
	{
		(*grid_info).grid[i] = malloc((1000000) * sizeof(char));
		if (!(*grid_info).grid[i])
			return ;
		j = 0;
		while (read(0, buff, sizeof(buff)))
		{
			if (*buff == '\n')
			{
				(*grid_info).grid[i][j] = 0;
				(*grid_info).width = j++;
				break ;
			}
			(*grid_info).grid[i][j++] = *buff;
		}
		i++;
	}
}

t_grid_info	standard_grid(int i, int j)
{
	t_grid_info	grid_info;

	grid_info.grid = NULL;
	if (!init_params(&grid_info, 0))
		return (grid_info);
	grid_info.grid = malloc(grid_info.height * sizeof(char *));
	if (!grid_info.grid)
		return (grid_info);
	fill_grid(&grid_info, i, j);
	return (grid_info);
}
