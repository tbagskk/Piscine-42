/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/01 23:42:42 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/03 16:07:31 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef BSQ_H
# define BSQ_H

# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include <fcntl.h>

# define BUFFER_SIZE 100000000

typedef struct s_grid_info
{
	int		height;
	int		width;
	char	empty_char;
	char	fill_char;
	char	obstacle_char;
	char	**grid;
}	t_grid_info;

typedef struct s_grid_solution
{
	t_grid_info	grid_info;
	int			**grid;
}	t_grid_solution;

typedef struct s_point
{
	int	x;
	int	y;
	int	value;
}	t_point;

typedef struct s_square
{
	t_point	corner_ul;
	t_point	corner_ur;
	t_point	corner_bl;
	t_point	corner_br;
}	t_square;

void			fill_file_grid(t_grid_info grid_info, char *buffer);

void			empty(char *buff);

void			ft_putchar(char c);

void			arg_main(int ac, char *av[], t_grid_info *grid_info);

void			fill_grid(t_grid_info *grid_info, int i, int j);

void			get_points(t_point corner_br, t_square *square);

void			solve_grid(t_grid_info grid_info);

int				init_params(t_grid_info *grid_info, int FILE_READ);

int				line_length(char *buffer);

int				ft_strlen(char *buff);

int				ft_atoi(char *str, int limit);

int				verif_params(t_grid_info grid_info);

int				verif_char(t_grid_info grid_info, char c);

int				verif_grid(t_grid_info grid_info);

int				in_square(t_square square, int x, int y);

int				print_solve(t_grid_info grid_info, t_point corner_br);

int				max(int a, int b, int c);

t_grid_info		file_grid(char *file, char *buff);

t_grid_info		standard_grid(int i, int j);

t_grid_solution	generate_solution(t_grid_info grid_info);

#endif
