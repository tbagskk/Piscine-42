/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   interpret.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/03 16:13:48 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/03 16:14:26 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "bsq.h"

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	get_points(t_point corner_br, t_square *square)
{
	(*square).corner_ul.x = corner_br.x - corner_br.value + 1;
	(*square).corner_ul.y = corner_br.y - corner_br.value + 1;
	(*square).corner_ur.x = corner_br.x;
	(*square).corner_ur.y = corner_br.y - corner_br.value + 1;
	(*square).corner_bl.x = corner_br.x - corner_br.value + 1;
	(*square).corner_bl.y = corner_br.y;
	(*square).corner_br.x = corner_br.x;
	(*square).corner_br.y = corner_br.y;
}

int	in_square(t_square square, int x, int y)
{
	if (x < square.corner_ul.x || x > square.corner_ur.x)
		return (0);
	if (y < square.corner_ul.y || y > square.corner_bl.y)
		return (0);
	return (1);
}

int	print_solve(t_grid_info grid_info, t_point corner_br)
{
	t_square	square;
	int			i;
	int			j;

	get_points(corner_br, &square);
	i = 0;
	while (i < grid_info.height)
	{
		j = 0;
		while (j < grid_info.width)
		{
			if (in_square(square, j, i))
				ft_putchar(grid_info.fill_char);
			else
				ft_putchar(grid_info.grid[i][j]);
			j++;
		}
		ft_putchar('\n');
		i++;
	}
	return (1);
}
