/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/03 16:12:42 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/03 16:12:48 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str, int limit)
{
	int	total;
	int	count;

	total = 0;
	count = 0;
	while (*str && *str < '0' && *str > '9')
		str++;
	while (*str >= '0' && *str <= '9' && count++ < limit)
		total = total * 10 + *str++ - '0';
	return (total);
}
