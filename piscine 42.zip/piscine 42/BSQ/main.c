/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alecoutr <alecoutr@student.42mulhouse.fr>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/01 23:19:25 by alecoutr          #+#    #+#             */
/*   Updated: 2022/08/01 23:21:01 by alecoutr         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "bsq.h"

void	arg_main(int ac, char *av[], t_grid_info *grid_info)
{
	int		i;
	char	*buff;
	int		j;

	i = 1;
	while (i < ac)
	{
		buff = malloc(50000000 * sizeof(char));
		*grid_info = file_grid(av[i++], buff);
		if (!verif_grid(*grid_info))
			(write(2, "map error.\n", 11));
		else
		{
			j = 0;
			solve_grid(*grid_info);
			while (j < (*grid_info).height)
				free((*grid_info).grid[j++]);
			free((*grid_info).grid);
		}
		free(buff);
		if (i < ac)
			write(1, "\n", 1);
	}
}

int	main(int ac, char *av[])
{
	t_grid_info	grid_info;

	if (ac == 1)
	{
		grid_info = standard_grid(0, 0);
		if (!verif_grid(grid_info))
			return (write(2, "map error.", 11));
		write(1, "\n", 1);
		solve_grid(grid_info);
	}
	else
		arg_main(ac, av, &grid_info);
}
