/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   brut_force.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 03:16:46 by gcherqui          #+#    #+#             */
/*   Updated: 2022/07/24 16:09:42 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
void	rtrn_error(void);
int		test_tab(char *str, char *args, int *loop);

int	tab_loop(char *str, char *args)
{
	int	loop[4];

	loop[0] = -1;
	loop[1] = -1;
	loop[2] = -1;
	loop[3] = -1;
	while (++loop[0] < 24)
	{
		while (++loop[1] < 24)
		{
			while (++loop[2] < 24)
			{
				while (++loop[3] < 24)
				{
					if (test_tab(str, args, loop) == 1)
						return (1);
				}
				loop[3] = -1;
			}
			loop[2] = -1;
		}
		loop[1] = -1;
	}
	rtrn_error();
	return (0);
}
