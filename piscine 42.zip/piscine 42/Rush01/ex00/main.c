/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcherrie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 16:13:49 by fcherrie          #+#    #+#             */
/*   Updated: 2022/07/24 18:56:06 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

char	*tab_init(void);
int		tab_loop(char *str, char *sujet);
void	rtrn_error(void);
char	*rm_spaces(char *ch);
int		argv_verif(char *arg);

int	main(int argc, char **argv)
{	
	char	*a;
	char	*e;

	if (argc != 2 || argv_verif(argv[1]) == 1)
	{
		rtrn_error();
		return (0);
	}
	a = tab_init();
	e = rm_spaces(argv[1]);
	tab_loop(a, e);
	free(a);
	free(e);
}
