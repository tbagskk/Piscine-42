/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   argv_verif.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <ngalzand@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 16:06:07 by ngalzand          #+#    #+#             */
/*   Updated: 2022/07/24 17:04:36 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	argv_verif(char	*arg)
{
	int	i;
	int	len;

	i = 1;
	len = 0;
	while (arg[len] != '\0')
		len++;
	if (len != 31)
		return (1);
	while (i < len)
	{
		if ((arg[i - 1] >= '1' && arg[i - 1] <= '4') && (arg[i] == ' '))
			i += 2;
		else
			return (1);
	}
	if (arg[i - 1] < '1' || arg[i - 1] > '4')
		return (1);
	return (0);
}
