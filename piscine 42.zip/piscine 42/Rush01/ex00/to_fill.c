/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   to_fill.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 02:50:50 by gcherqui          #+#    #+#             */
/*   Updated: 2022/07/24 18:07:25 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

char	*to_fill1(char *str, int a, int b)
{
	int		i;
	char	*tab;

	i = 0;
	tab = (char *) malloc(sizeof(char) * 9);
	while (i < 4)
	{
		tab[i++] = str[a++];
	}
	while (i < 8)
	{
		tab[i++] = str[b++];
	}	
	return (tab);
}

char	*to_fill2(char *str, int a, int b)
{
	int		i;
	char	*tab;

	i = 0;
	tab = (char *)malloc(sizeof(char) * 9);
	while (i < 4)
	{
	tab[i++] = str[a++];
	}
	while (i < 8)
	{
	tab[i++] = str[b++];
	}
	return (tab);
}

char	*to_fill(char *tab1, char *tab2)
{
	int		i;
	int		compteur;
	int		compteur2;
	char	*tab;

	i = 0;
	compteur = 0;
	compteur2 = 0;
	tab = (char *)malloc(sizeof(char) * 17);
	while (i < 17)
	{
		if (i < 8)
			tab[i] = tab1[compteur];
		if (i >= 8)
		{
			tab[i] = tab2[compteur2];
			compteur2++;
		}
		compteur++;
		i++;
	}	
	return (tab);
}
