/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rm_spaces.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ngalzand <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 11:31:53 by ngalzand          #+#    #+#             */
/*   Updated: 2022/07/24 18:24:48 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*rm_spaces(char *ch)
{	
	int		i;
	int		n;
	char	*result;

	i = 0;
	n = 0;
	result = (char *)malloc(sizeof(char) * 17);
	while (*(ch + i))
	{
		if (*(ch + i) >= '1' && *(ch + i) <= '4')
		{
			result[n] = ch[i];
			n++;
		}
		i++;
	}
	return (result);
}
