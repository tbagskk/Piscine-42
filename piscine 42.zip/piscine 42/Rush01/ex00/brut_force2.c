/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   brut_force2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcherrie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 11:40:35 by fcherrie          #+#    #+#             */
/*   Updated: 2022/07/24 18:52:48 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_display(char *tab);
int		verif_view(char *tab, char *args);
int		duplicates_verif(char *tab);
char	*to_fill(char *tab1, char *tab2);
char	*to_fill1(char *str, int a, int b);
char	*to_fill2(char *str, int a, int b);

int	test_tab(char *str, char *args, int *loop)
{
	char	*tab;
	char	*tab2;
	char	*tab3;

	tab2 = to_fill1(str, (loop[0] * 5), (loop[1] * 5));
	tab3 = to_fill2(str, (loop[2] * 5), (loop[3] * 5));
	tab = to_fill(tab2, tab3);
	if (duplicates_verif(tab))
	{
		if (!(verif_view(tab, args)))
		{
			ft_display(tab);
			return (1);
		}
	}
	return (0);
}
