/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   verif_view.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcherrie <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/23 19:35:13 by fcherrie          #+#    #+#             */
/*   Updated: 2022/07/24 11:35:53 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	verif_view_col_up(char *tab, char *args, int c)
{
	int	i;

	i = 1;
	if (tab[4 + c] > tab[0 + c])
		i++;
	if (tab[8 + c] > tab[4 + c] && tab[8 + c] > tab[0 + c])
		i++;
	if (tab[12 + c] > tab[8 + c] && tab[12 + c] > tab[4 + c]
		&& tab[12 + c] > tab[0 + c])
		i++;
	if (args[0 + c] == '0' + i)
		return (0);
	return (1);
}

int	verif_view_col_down(char *tab, char *args, int c)
{
	int	i;

	i = 1;
	if (tab[8 + c] > tab[12 + c])
		i++;
	if (tab[4 + c] > tab[8 + c] && tab[4 + c] > tab[12 + c])
		i++;
	if (tab[0 + c] > tab[4 + c] && tab[0 + c] > tab[8 + c]
		&& tab[0 + c] > tab[12 + c])
		i++;
	if (args[4 + c] == '0' + i)
		return (0);
	return (1);
}

int	verif_view_line_left(char *tab, char *args, int c)
{
	int	i;

	i = 1;
	if (tab[1 + 4 * c] > tab[0 + 4 * c])
		i++;
	if (tab[2 + 4 * c] > tab[1 + 4 * c] && tab[2 + 4 * c] > tab[0 + 4 * c])
		i++;
	if (tab[3 + 4 * c] > tab[2 + 4 * c] && tab[3 + 4 * c] > tab[1 + 4 * c]
		&& tab[3 + 4 * c] > tab[0 + 4 * c])
		i++;
	if (args[8 + c] == '0' + i)
		return (0);
	return (1);
}

int	verif_view_line_right(char *tab, char *args, int c)
{
	int	i;

	i = 1;
	if (tab[2 + 4 * c] > tab[3 + 4 * c])
		i++;
	if (tab[1 + 4 * c] > tab[2 + 4 * c] && tab[1 + 4 * c] > tab[3 + 4 * c])
		i++;
	if (tab[0 + 4 * c] > tab[1 + 4 * c] && tab[0 + 4 * c] > tab[2 + 4 * c]
		&& tab[0 + 4 * c] > tab[3 + 4 * c])
		i++;
	if (args[12 + c] == '0' + i)
		return (0);
	return (1);
}

int	verif_view(char *tab, char *args)
{
	int	c;

	c = 0;
	while (c < 4)
	{
		if (verif_view_col_up(tab, args, c) == 1)
			return (1);
		if (verif_view_col_down(tab, args, c) == 1)
			return (1);
		if (verif_view_line_right(tab, args, c) == 1)
			return (1);
		if (verif_view_line_left(tab, args, c) == 1)
			return (1);
		c++;
	}
	return (0);
}
