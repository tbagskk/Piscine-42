/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tabb.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/24 03:09:37 by gcherqui          #+#    #+#             */
/*   Updated: 2022/07/24 14:44:01 by fcherrie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

char	*tab_init(void)
{
	char	*tab;
	char	*tab2;
	char	*tab_final;
	int		i;

	i = 0;
	tab_final = (char *)malloc(sizeof(char) * 121);
	tab = "4321 4312 4213 4231 4123 4132 3421 3412 3241 3214 3142 3124";
	tab2 = " 2431 2413 2341 2314 2134 2143 1423 1432 1342 1324 1234 1243";
	while (tab[i])
		i++;
	i = 0;
	while (i < 59)
	{
		tab_final[i] = tab[i];
		i++;
	}
	i = 0;
	while (i < 60)
	{
		tab_final[i + 59] = tab2[i];
		i++;
	}
	return (tab_final);
}
