/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/31 19:38:23 by gcherqui          #+#    #+#             */
/*   Updated: 2022/07/31 23:36:25 by ^@^ Foxan ^@^    ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	free_3d_tab(char ***tab_to_free, int len);

char	***parsefile(char *file, int *len);

int		len_str(char *str);

char	*find(char fo_find, char ***dict, int dozen);

char	*find_separator(int nb_zeros, char ***dict, int nb_lines);

void	display(char *number, char ***dict, int nb_lines);

char	*ft_clean(char *str);

void	error(void);

int	main(int ac, char **av)
{
	int		len;
	char	***tab;
	char	*tableau;

	if (ac == 2)
	{
		tab = parsefile("numbers.dict", &len);
		tableau = ft_clean(av[1]);
	}
	if (ac == 3)
	{
		tab = parsefile(av[1], &len);
		tableau = ft_clean(av[2]);
	}
	if (!tableau || ac > 3)
		error();
	else
		display(tableau, tab, len);
	free_3d_tab(tab, len);
}
