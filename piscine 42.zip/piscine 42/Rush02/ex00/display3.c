/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display3.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ^@^ Foxan ^@^ <thibaut.unsinger@gmail.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/31 22:15:15 by ^@^ Foxan ^@^     #+#    #+#             */
/*   Updated: 2022/07/31 22:15:17 by ^@^ Foxan ^@^    ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "protos.h"

void	display_if3(int *indexes, char *number, char ***dict, int nb_lines)
{
	if (indexes[0] % 3 == 2
		&& (number[indexes[1]] != '0' || (indexes[1] > 0
				&& number[indexes[1] - 1] != '0')
			|| (indexes[1] > 1 && number[indexes[1] - 2] != '0')))
	{
		if (indexes[1] < len_str(number) - 1)
			ft_pustr(" ");
		ft_pustr(find_separator(
				len_str(number) - indexes[1] - 1, dict, nb_lines));
	}
}
