/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ^@^ Foxan ^@^ <thibaut.unsinger@gmail.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/30 21:43:11 by ^@^ Foxan ^@^     #+#    #+#             */
/*   Updated: 2022/07/31 13:34:33 by llion            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "protos.h"

char	*find(char to_find, char ***dict, int dozen, int size)
{
	int	i;

	i = 0;
	if (to_find == '0' && size != 1)
		return ("");
	if (!dozen)
		while (!(to_find == dict[i][0][0] && dict[i][0][1] == '\0'))
			i++;
	else
		while (!(to_find == dict[i][0][0] && dict[i][0][1] == '0'
				&& dict[i][0][2] == '\0'))
			i++;
	return (dict[i][1]);
}

char	*find_separator(int nb_zeros, char ***dict, int nb_lines)
{
	int	i;
	int	j;
	int	count;

	if (nb_zeros == 0)
		return ("");
	i = 0;
	while (i < nb_lines)
	{
		if (len_str(dict[i][0]) - 1 == nb_zeros)
		{
			if (dict[i][0][0] == '1')
			{
				j = 0;
				count = 0;
				while (dict[i][0][++j] != '\0')
					if (dict[i][0][j] == '0')
						count++;
				if (count == nb_zeros)
					return (dict[i][1]);
			}
		}
		i++;
	}
	return (NULL);
}

int	verif(char *number)
{
	int	index;
	int	i;

	i = -1;
	if (len_str(number) % 3 == 0)
		index = 0;
	else if (len_str(number) % 3 == 2)
		index = 1;
	else
		index = 2;
	return (index);
}

void	display_ifs(int *indexes, char ***dict, int nb_lines, char *number)
{
	if (indexes[0] % 3 == 0)
	{
		ft_pustr(find(number[indexes[1]], dict, 0, len_str(number)));
		ft_pustr(" ");
		ft_pustr(find_separator(2, dict, nb_lines));
	}
	if (indexes[0] % 3 == 1)
	{
		if (number[indexes[1]] != '1')
			ft_pustr(find(number[indexes[1]], dict, 1, len_str(number)));
		else
			ft_pustr(dozen(number[indexes[1]], number[indexes[1] + 1], dict));
	}
}

void	display(char *number, char ***dict, int nb_lines)
{
	int	i;
	int	index;
	int	indexes[2];

	index = verif(number);
	i = -1;
	while (++i < len_str(number))
	{
		espace(i, number);
		if (number[i] == '0' && len_str(number) == 1)
			ft_pustr(find('0', dict, 0, 1));
		else
		{
			if (number[i] != '0')
			{
				indexes[0] = index;
				indexes[1] = i;
				display_ifs(indexes, dict, nb_lines, number);
			}
			display_if2(index, number, i, dict);
			indexes[0] = index++;
			indexes[1] = i;
			display_if3(indexes, number, dict, nb_lines);
		}
	}
}
