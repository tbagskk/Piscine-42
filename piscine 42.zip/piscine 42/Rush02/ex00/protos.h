/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   protos.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ^@^ Foxan ^@^ <thibaut.unsinger@gmail.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/31 22:15:06 by ^@^ Foxan ^@^     #+#    #+#             */
/*   Updated: 2022/07/31 22:15:08 by ^@^ Foxan ^@^    ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//
// Created by Thibaut Unsinger on 7/31/22.
//

#ifndef PROTOS_H
# define PROTOS_H

void	free_3d_tab(char ***tab_to_free, int len);

char	***parsefile(char *file, int *len);

int		len_str(char *str);

char	*find(char fo_find, char ***dict, int dozen, int size);

char	*find_separator(int nb_zeros, char ***dict, int nb_lines);

void	display(char *number, char ***dict, int nb_lines);

char	*dozen(char d, char u, char ***dict);

void	espace(int i, char *number);

int		len_str(char *str);

void	display_if2(int index, char *number, int i, char ***dict);

void	ft_pustr(char *str);

void	display_if3(int *indexes, char *number, char ***dict, int nb_lines);

#endif
