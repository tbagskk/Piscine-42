/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_clean.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gcherqui <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/31 19:44:56 by gcherqui          #+#    #+#             */
/*   Updated: 2022/07/31 19:54:43 by gcherqui         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	len_str(char *str);

char	*ft_clean(char *str)
{
	int		i;
	int		j;
	char	*tab;
	int		len;

	j = 0;
	tab = malloc(sizeof(char) * (len_str(str) + 1));
	tab[len_str(str)] = '\0';
	i = 0;
	while (str[i])
	{
		if (str[i] == '-' || str[i] == '+'
			|| str[i] == ' ' || str[i] == '\t')
			if (str[i + 1] == '-' || str[i + 1] == '+'
				|| str[i + 1] == ' ' || str[i] == '\t')
				return (0);
		if (!(str[i] >= '0' && str[i] <= '9'))
			return (0);
		while (str[i] >= '0' && str[i] <= '9')
		{
			tab[j++] = str[i++];
		}
	}
	return (tab);
}
