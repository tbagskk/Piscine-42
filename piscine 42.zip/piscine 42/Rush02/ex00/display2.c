/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display2.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ^@^ Foxan ^@^ <thibaut.unsinger@gmail.com  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/31 21:35:20 by ^@^ Foxan ^@^     #+#    #+#             */
/*   Updated: 2022/07/31 21:35:22 by ^@^ Foxan ^@^    ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "protos.h"

char	*dozen(char d, char u, char ***dict)
{
	int		i;

	i = 0;
	while (!(d == dict[i][0][0] && u == dict[i][0][1] && '\0' == dict[i][0][2]))
		i++;
	return (dict[i][1]);
}

void	espace(int i, char *number)
{
	if (!(len_str(number) % 3 == 2 && number[i - 1] == '1'))
		if (number[i] != '0' && i != 0)
			ft_pustr(" ");
}

int	len_str(char *str)
{
	int	len;

	len = 0;
	while (str[len])
		len++;
	return (len);
}

void	ft_pustr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

void	display_if2(int index, char *number, int i, char ***dict)
{
	if (index % 3 == 2)
		if (number[i - 1] != '1')
			ft_pustr(find(
					number[i], dict, 0, len_str(number)));
}
