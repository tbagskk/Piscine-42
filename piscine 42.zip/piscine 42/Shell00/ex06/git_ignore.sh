git status -s --ignored | grep '!' | tr -d '! ' 
